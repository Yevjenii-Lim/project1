import Swiper from 'swiper';
console.log('asdasd')
let burger = document.querySelector('.burger')
let mobileMenu = document.querySelector('.mobileMenu')
let overLay = document.querySelector('.overLay')
let close = document.querySelector('.close')
let navBarListItem = document.querySelectorAll('.nav-list__item')
let innerList = document.querySelectorAll('.inner-list')


for(let i of navBarListItem) {
    i.addEventListener('mouseover', openInnerList)
}

for(let i of innerList) {
    i.addEventListener('mouseout', closeInnerList)
}

burger.addEventListener('click', openMenu)
close.addEventListener('click', closeMenu)
overLay.addEventListener('click', closeMenu)
function openMenu() {
    mobileMenu.style.transform = 'translateX(0%)'
    overLay.style.display = 'block'
}

function closeMenu() {
    mobileMenu.style.transform = 'translateX(-100%)'
    overLay.style.display = 'none'
}

function openInnerList(event) {
    let innerList = event.target.querySelector('.inner-list')
    innerList.style.display = 'block'
}

function closeInnerList(event) {
    let innerList = event.target.parentElement
    innerList.style.display = 'none'
}

var mySwiper = new Swiper('.swiper-container', {
    // Optional parameters
    direction: 'vertical',
    loop: true,
  
    // If we need pagination
    pagination: {
      el: '.swiper-pagination',
    },
  
    // Navigation arrows
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  
    // And if we need scrollbar
    scrollbar: {
      el: '.swiper-scrollbar',
    },
  })

console.log(swiper)